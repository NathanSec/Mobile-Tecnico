package com.example.tarefa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tarefa.ui.theme.TarefaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TarefaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Artigo()
                }
            }
        }
    }
}

@Composable
fun Artigo() {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Imagem()
        Titulo()
        Resumo()
        CorpoDoTexto()
    }
}

@Composable
fun Imagem() {
    val imagem = painterResource(R.drawable.ferrarif40)
    Image(
        painter = imagem,
        contentDescription = null,
        modifier = Modifier
            .height(30.dp)
            .fillMaxWidth(),
        contentScale = ContentScale.FillWidth
    )
}

@Composable
fun Titulo() {
        Text(
            text = "A FERRARI F40",
            modifier = Modifier.padding(16.dp),
            color = Color.Black,
            textAlign = TextAlign.Center,
            fontSize = 24.sp

        )
    }



@Composable
fun Resumo() {
    Box (
        modifier = Modifier
            .background(Color.Red)
            .fillMaxWidth(),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(
            text = "A Ferrari F40 é um supercarro clássico dos anos 80, celebrando o 40º aniversário da Ferrari. Conhecido por seu motor V8 biturbo e design leve, é altamente aclamado por seu desempenho e velocidade.",

            modifier = Modifier.padding(
                start = 16.dp,
                end = 16.dp
            ),
            textAlign = TextAlign.Justify,
            color = Color.White
        )
    }
}

@Composable
fun CorpoDoTexto() {
    Text(
        text = "Desenvolvida sob a orientação de Enzo Ferrari, o lendário fundador da marca, a F40 foi concebida para ser a derradeira expressão do que um carro esportivo poderia ser. Seu objetivo não era apenas ser rápido, mas sim transcendental, uma fusão de arte e engenharia que capturaria a imaginação de todos os que a vissem.O design da F40 é uma obra-prima de simplicidade e agressão. Cada linha e curva é funcional, destinada a melhorar a aerodinâmica e a resfriar o motor turboalimentado que reside atrás dos bancos dianteiros.",
        modifier = Modifier.padding(16.dp),
        textAlign = TextAlign.Justify,
        color = Color.Black
    )
}


@Preview(showBackground = true)
@Composable
fun PreviewArtigo() {
    TarefaTheme {
        Artigo()
    }
}
