package com.example.cartao

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cartao.ui.theme.CartaoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CartaoTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black
                ) {
                    InformacoesCaixa(
                        nome = stringResource(R.string.texto_nome),
                        titulo = stringResource(R.string.texto_titulo),
                        telefone = stringResource(R.string.texto_tel),
                        repo = stringResource(R.string.texto_repo),
                        email = stringResource(R.string.texto_email)
                    )
                }
            }
        }
    }
}

@Composable
fun InformacoesCaixa(
    nome: String,
    titulo: String,
    telefone: String,
    repo: String,
    email: String
) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier.padding(start = 32.dp, top = 16.dp, end = 32.dp, bottom = 16.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.image1),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(230.dp),
                contentScale = ContentScale.FillWidth
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = nome,
                fontSize = 24.sp,
                textAlign = TextAlign.Center,
                color = Color.Blue
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = titulo,
                fontSize = 16.sp,
                textAlign = TextAlign.Justify,
                maxLines = 5,
                color = Color.Blue
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = telefone,
                fontSize = 16.sp,
                textAlign = TextAlign.Justify,
                maxLines = 5,
                color = Color.Blue
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = repo,
                fontSize = 16.sp,
                textAlign = TextAlign.Justify,
                maxLines = 5,
                color = Color.Blue
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = email,
                fontSize = 16.sp,
                textAlign = TextAlign.Justify,
                maxLines = 5,
                color = Color.Blue
            )
        }
    }
}

