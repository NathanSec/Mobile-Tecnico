package com.example.galeriadefotos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.galeriadefotos.ui.theme.GaleriaDeFotosTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GaleriaDeFotosTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    color = Color.Red,
                    modifier = Modifier.fillMaxSize(),
                ) {
                    Galeria()
                }
            }
        }
    }
}

@Composable
fun Galeria() {
    val fotos = listOf(
        Foto("Drift 350z", "Nissan", 2004, R.drawable._50z),
        Foto("Nascar Camry", "Toyota", 2022, R.drawable.toyota),
        Foto("GTR Nismo", "Nissan", 2022, R.drawable.nismo),
        Foto("Subaru WRC Rally", "Subaru", 2025, R.drawable.subaru),
        Foto("Endurance", "Ferrari", 2023, R.drawable.ferrari)
    )

    var fotoAtualIndex by remember { mutableStateOf(0) }
    val fotoAtual = fotos[fotoAtualIndex]

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(320.dp)
                .padding(20.dp)
                .border(1.dp, Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = fotoAtual.imagemResId),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp),
                contentScale = ContentScale.Crop,

            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Column {
            Text(text = fotoAtual.titulo)
            Row(
                horizontalArrangement = Arrangement.SpaceAround,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = fotoAtual.autor)
                Text(text = fotoAtual.ano.toString())
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = { if (fotoAtualIndex > 0) fotoAtualIndex-- },
                modifier = Modifier.padding(end = 8.dp)
            ) {
                Text("Anterior", color = Color.White)
            }

            Button(
                onClick = { if (fotoAtualIndex < fotos.size - 1) fotoAtualIndex++ },
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text("Próxima", color = Color.White)
            }
        }
    }
}

data class Foto(
    val titulo: String,
    val autor: String,
    val ano: Int,
    val imagemResId: Int
)

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    GaleriaDeFotosTheme {
        Galeria()
    }
}
